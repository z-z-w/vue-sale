// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import IndexPage from './pages/index'
import OrderListPage from './pages/orderList'
import DetailPage from './pages/detail'
import ForeCastPage from './pages/detail/forecast'
import CountPage from './pages/detail/count'
import AnalysisPage from './pages/detail/analysis'
import PublishPage from './pages/detail/publish'


import VueRouter from 'vue-router'
import VueReource from 'vue-resource'



Vue.use(VueRouter);
Vue.use(VueReource);
let router = new VueRouter({
    mode: 'history',
    routes: [
        {
            path: '/',
            component: IndexPage
        },
        {
            path: '/orderList',
            component: OrderListPage
        },
        {
            path: '/detail',
            component: DetailPage,
            redirect: '/detail/count',
            children: [
                {
                    path: 'forecast',
                    component: ForeCastPage
                },
                {
                    path: 'count',
                    component: CountPage
                },
                {
                    path: 'analysis',
                    component: AnalysisPage
                },
                {
                    path: 'publish',
                    component: PublishPage
                }
            ]
        }
    ]
})

Vue.config.productionTip = false

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  components: { App },
  template: '<App/>'
})
